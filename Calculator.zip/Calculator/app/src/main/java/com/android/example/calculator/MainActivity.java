package com.android.example.calculator;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputNumber;
    private Button calculateButton;
    private TextView resultsView;

    private int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNumber = findViewById(R.id.inputNumber);
        calculateButton = findViewById(R.id.calculateButton);
        resultsView = findViewById(R.id.resultsView);

        inputNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void afterTextChanged(Editable editable) {
                calculateButton.setEnabled(true);
            }
        });

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String input = inputNumber.getText().toString();

                if (input.isEmpty()) {
                    return;
                }

                double number = Double.parseDouble(input);

                if (number < 0) {
                    calculateButton.setEnabled(false);
                    return;
                }

                double root = Math.sqrt(number);

                if (count == 5) {
                    resultsView.setText("");
                    count = 0;
                    inputNumber.setText("");
                }

                resultsView.append(String.format("%.2f\n", root));
                count++;


                calculateButton.setEnabled(false);
            }
        });
    }
}
